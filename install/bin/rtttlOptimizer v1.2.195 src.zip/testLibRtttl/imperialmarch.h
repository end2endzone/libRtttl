#ifndef IMPERIALMARCH_H
#define IMPERIALMARCH_H

#include "notes.h"

void playImperialMarch(int iPinNumber);
void dumpImperialMarchToneCalls(const char * iFilename);
void convertImperialMarch2NoteDelayArray(const char * iArrayName, const char * iFilename);

#endif //IMPERIALMARCH_H
