// Include the stdwx.h in every .cpp file
#include "stdwx.h"
